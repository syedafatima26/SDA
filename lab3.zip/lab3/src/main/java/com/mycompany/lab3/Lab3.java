/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.lab3;

/**
 *
 * @author DELL
 */
public class Lab3 {

    public static void main(String[] args) {
       Seat businessClass = new BusinessClass();
        Seat firstClass = new FirstClass();
        Seat economyClass = new EconomyClass();

        // Set a common number of seats (you can change the number as needed)
        int numberOfSeats = 5;

        // Use polymorphism to calculate and display prices for each seat type
        System.out.println("Price for Business Class: " + businessClass.calculateSeatPrice(numberOfSeats));
        System.out.println("Price for First Class: " + firstClass.calculateSeatPrice(numberOfSeats));
        System.out.println("Price for Economy Class: " + economyClass.calculateSeatPrice(numberOfSeats));
    }
}