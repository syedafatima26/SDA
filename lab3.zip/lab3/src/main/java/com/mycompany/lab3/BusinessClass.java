/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab3;

/**
 *
 * @author DELL
 */
public class BusinessClass extends Seat {
    private static final double PRICE_PER_SEAT = 300000.0; 

    @Override
    public double calculateSeatPrice(int numberOfSeats) {
        return numberOfSeats * PRICE_PER_SEAT;
    }
    
}