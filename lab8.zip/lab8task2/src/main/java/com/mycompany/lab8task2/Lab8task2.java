/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.lab8task2;

/**
 *
 * @author DELL
 */
public class Lab8task2 {

  public static void main(String[] args) {
        USPlug usPlug = new USPlug();
        
        EuropeanSocket socketAdapter = new SocketAdapter(usPlug);
        
        socketAdapter.plugIn();
    }
}