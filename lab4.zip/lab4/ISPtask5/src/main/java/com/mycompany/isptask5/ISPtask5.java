/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.isptask5;

/**
 *
 * @author DELL
 */
public class ISPtask5 {

    public static void main(String[] args) {
     
        Printer printer = new Printer();
        Scanner scanner = new Scanner();
        MultiFunctionDevice multiFunctionDevice = new MultiFunctionDevice();

        printer.print();                
        scanner.scan();     
        multiFunctionDevice.print();  
        multiFunctionDevice.scan();  
    }
}
