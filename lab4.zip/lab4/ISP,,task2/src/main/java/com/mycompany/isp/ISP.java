/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.isp;

/**
 *
 * @author DELL
 */
public class ISP {

    public static void main(String[] args) {
        // Create an instance of ProgrammingLanguage with the name "Java"
        ProgrammingLanguage java = new ProgrammingLanguage("Java");

        // Call the getName method to display the programming language name
        System.out.println("Programming Language: " + java.getName());
    }
}
