/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.lsp;

/**
 *
 * @author DELL
 */
public class LSP {

   public static void main(String[] args) {
        Animal cat = new Cat(); 
        cat.makeSound(); 

        SoundMaker robotCat = new RobotCat(); 
        robotCat.makeSound();  
    }
}