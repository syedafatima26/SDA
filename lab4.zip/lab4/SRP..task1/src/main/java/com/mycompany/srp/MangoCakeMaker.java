/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.srp;

/**
 *
 * @author DELL
 */
public class MangoCakeMaker {
 
    private IngredientPreparer ingredientPreparer = new IngredientPreparer();
    private Mixer mixer = new Mixer();
    private Baker baker = new Baker();
    private ToppingPreparer toppingPreparer = new ToppingPreparer();
    private Decorator decorator = new Decorator();
    private Cleaner cleaner = new Cleaner();

    public void makeMangoCake() {
        // Step 1: Prepare Ingredients
        String[] ingredients = {"Flour", "Eggs", "Sugar", "Butter", "Mango"};
        ingredientPreparer.prepareIngredients(ingredients);

        // Step 2: Mix Ingredients
        mixer.mixIngredients();

        // Step 3: Bake the Cake
        baker.bake(180, 30);

        // Step 4: Prepare Mango Topping
        toppingPreparer.prepareMangoTopping();

        // Step 5: Decorate the Cake
        decorator.decorate();

        // Step 6: Clean the Kitchen
        cleaner.cleanKitchen();
    } 
}